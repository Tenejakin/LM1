"""AprilTag-referenced monocular launch estimates. All distances internally in metres.

World +X follows the tag's top edge (target), +Y points left, +Z up.
Single-view sphere depth is sensitive to silhouette errors; never label it measured 3D.
"""
from __future__ import annotations

import json
import math
import os
from pathlib import Path
import cv2
import numpy as np

from target_line import target_heading_rad

RADIUS = 0.021335
STRICT_TAG_POSE_ERROR_PX = 1.0
MAX_ESTIMATED_TAG_POSE_ERROR_PX = 3.0
MAX_GROUND_TAG_DETECTIONS = 12
STRICT_BALL_FILL = 0.82
GUIDED_BALL_FILL = 0.50
GUIDED_MIN_SEQUENCE = 3
GUIDED_RADIUS_RATIO = 1.12
METRICS = {
    "ballSpeedMps": "m/s", "clubSpeedMps": "m/s", "smashFactor": "",
    "launchAngleDeg": "deg", "startDirectionDeg": "deg", "strikeXmm": "mm",
    "strikeYmm": "mm", "spinRpm": "rpm", "spinAxisDeg": "deg",
    "estimatedCarryM": "m", "rollDistanceM": "m", "skidDistanceM": "m",
}


def unavailable(reason):
    return {key: {"value": None, "unit": unit, "status": "unavailable", "reason": reason} for key, unit in METRICS.items()}


def load_setup(image_size):
    path = Path(os.getenv("PINPOINT_INTRINSICS_PATH", "/var/lib/pinpoint/intrinsics.json"))
    data = json.loads(path.read_text())
    matrix = np.asarray(data["cameraMatrix"], dtype=float)
    distortion = np.asarray(data["distCoeffs"], dtype=float)
    if list(image_size) != data["imageSize"]:
        raise ValueError("Lens calibration resolution differs from capture; recalibrate this sensor mode.")
    if matrix.shape != (3, 3) or not np.all(np.isfinite(matrix)) or min(matrix[0, 0], matrix[1, 1]) <= 0:
        raise ValueError("Invalid lens calibration matrix.")
    if not np.all(np.isfinite(distortion)) or not math.isfinite(data["rmsPx"]) or data["rmsPx"] > 0.7:
        raise ValueError("Lens calibration reprojection error exceeds 0.7 pixels.")
    return matrix, distortion


def solve_tag_pose(corners, size, matrix, distortion):
    """Solve a tag pose and return its reprojection error without applying a quality policy."""
    # +Y left and +Z above the printed side of the ground tag.
    points = np.array([[0, 0, 0], [size, 0, 0], [size, -size, 0], [0, -size, 0]], np.float64)
    corners = np.asarray(corners, np.float64)
    if corners.shape != (4, 2) or not np.all(np.isfinite(corners)):
        raise ValueError("AprilTag corners are invalid.")
    ok, rotation, translation = cv2.solvePnP(points, corners, matrix, distortion, flags=cv2.SOLVEPNP_ITERATIVE)
    if not ok or translation[2, 0] <= 0:
        raise ValueError("AprilTag pose could not be solved.")
    projected, _ = cv2.projectPoints(points, rotation, translation, matrix, distortion)
    error = float(np.sqrt(np.mean(np.sum((projected.reshape(-1, 2) - corners) ** 2, axis=1))))
    if not math.isfinite(error):
        raise ValueError("AprilTag pose reprojection error is invalid.")
    return cv2.Rodrigues(rotation)[0], translation.reshape(3), error


def tag_pose(corners, size, matrix, distortion):
    """Strict pose used by moving club tags, whose per-frame position cannot be substituted."""
    rotation, translation, error = solve_tag_pose(corners, size, matrix, distortion)
    if error > STRICT_TAG_POSE_ERROR_PX:
        raise ValueError("AprilTag pose reprojection error exceeds one pixel.")
    return rotation, translation


def sphere_center(contour, matrix, distortion, radius=RADIUS):
    """Fit the tangent-ray cone of a known-radius sphere, including off-axis views."""
    points = np.asarray(contour, np.float64).reshape(-1, 2)
    if len(points) >= 8:
        # A ball's seam line, logo or shadowed edge dents the thresholded silhouette;
        # on real strikes those dents failed the distortion gate below on nearly every
        # frame. The sphere's outline is convex, so fit its convex hull points.
        hull = cv2.convexHull(points.astype(np.float32), returnPoints=False).reshape(-1)
        if len(hull) >= 5:
            points = points[np.sort(hull)]
    rays = cv2.undistortPoints(points.reshape(-1, 1, 2), matrix, distortion).reshape(-1, 2)
    rays = np.column_stack((rays, np.ones(len(rays))))
    rays /= np.linalg.norm(rays, axis=1)[:, None]
    _, _, vh = np.linalg.svd(rays - rays.mean(axis=0), full_matrices=False)
    axis = vh[-1]
    if axis[2] < 0:
        axis = -axis
    cosine = float(np.mean(rays @ axis))
    sine = math.sqrt(max(0, 1 - cosine * cosine))
    if sine < 0.002 or np.std(rays @ axis) > max(0.00002, (1 - cosine) * 0.2):
        raise ValueError("Ball silhouette is too small or distorted for depth estimation.")
    return axis * radius / sine


def fit_velocity(times, positions):
    times, positions = np.asarray(times), np.asarray(positions)
    if len(times) < 3 or np.any(np.diff(times) <= 0):
        raise ValueError("At least three increasing sensor timestamps are required.")
    design = np.column_stack((times - times[0], np.ones(len(times))))
    model = np.linalg.lstsq(design, positions, rcond=None)[0]
    residual = float(np.sqrt(np.mean(np.sum((design @ model - positions) ** 2, axis=1))))
    if residual > 0.008:
        raise ValueError("3D track fit error exceeds 8 mm.")
    return model[0], residual


def marker_map(frame):
    dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_APRILTAG_36h11)
    parameters = cv2.aruco.DetectorParameters()
    if hasattr(cv2.aruco, "ArucoDetector"):
        corners, ids, _ = cv2.aruco.ArucoDetector(dictionary, parameters).detectMarkers(frame)
    else:
        corners, ids, _ = cv2.aruco.detectMarkers(frame, dictionary, parameters=parameters)
    return {} if ids is None else {int(tag): points.reshape(4, 2) for tag, points in zip(ids.flatten(), corners)}


def target_rotation(heading):
    """Rotation about +Z taking the calibrated target heading onto +X (identity when unset)."""
    if heading is None:
        return np.eye(3)
    c, s = math.cos(-heading), math.sin(-heading)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def find_ground_tag_pose(frames, impact_index, ground_id, size, matrix, distortion):
    """Return the best static ground-tag pose from a bounded set of burst detections.

    The tag is static, so later or earlier frames can replace an imperfect detection near
    impact. Limiting valid detections bounds processing time while still comparing across
    lamp-flicker phases and temporary club/hand occlusion.
    """
    start = max(0, min(impact_index - 8, len(frames) - 1))
    order = [start]
    for step in range(5, len(frames), 5):
        for index in (start - step, start + step):
            if 0 <= index < len(frames):
                order.append(index)
    candidates = []
    for index in order:
        tags = marker_map(frames[index][1])
        if ground_id not in tags:
            continue
        try:
            rotation, translation, error = solve_tag_pose(tags[ground_id], size, matrix, distortion)
        except (ValueError, cv2.error, np.linalg.LinAlgError):
            continue
        candidates.append({"rotation": rotation, "translation": translation, "errorPx": error, "frameIndex": index})
        if len(candidates) >= MAX_GROUND_TAG_DETECTIONS:
            break
    return min(candidates, key=lambda candidate: candidate["errorPx"]) if candidates else None


def to_gray(frame):
    return frame if frame.ndim == 2 else cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


def ball_background(frames, impact_index):
    """Median of the pre-departure frames: the resting ball cancels, so only what moves stands out.

    A global brightness threshold cannot separate a white ball from a white tag sheet or a
    lit mat; differencing against the scene itself can.
    """
    stop = min(len(frames), max(3, impact_index - 8))
    stride = max(1, stop // 60)
    stack = np.stack([to_gray(frames[i][1]) for i in range(0, stop, stride)])
    return np.median(stack, axis=0).astype(np.uint8)


def ball_contours(frame, background, seed_radius, minimum_fill=STRICT_BALL_FILL):
    gray = to_gray(frame)
    # Mains-frequency lamp flicker shifts whole-frame brightness between consecutive frames.
    gain = float(background.mean()) / max(float(gray.mean()), 1.0)
    gray = np.clip(gray.astype(np.float32) * gain, 0, 255).astype(np.uint8)
    diff = cv2.subtract(gray, background)
    threshold, _ = cv2.threshold(diff, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    # Otsu returns 0 for a noise-free frame whose only change is one small blob, and
    # splits sensor noise on a frame where nothing moved; floor it at a real difference.
    _, mask = cv2.threshold(diff, max(threshold, 20), 255, cv2.THRESH_BINARY)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))
    # A ball's dark seam line cuts the white silhouette into two half-discs (or a
    # slit), each failing the fill test below; bridge gaps that narrow.
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    found = []
    for contour in contours:
        if len(contour) < 12:
            continue
        (x, y), radius = cv2.minEnclosingCircle(contour)
        area = cv2.contourArea(contour)
        if not max(5, seed_radius * 0.45) <= radius <= seed_radius * 1.8 or area / (math.pi * radius ** 2) < minimum_fill:
            continue
        if min(x - radius, y - radius) < 2 or x + radius >= gray.shape[1] - 2 or y + radius >= gray.shape[0] - 2:
            continue
        found.append((np.array([x, y]), contour))
    return found


def circle_contour(center, radius, count=64):
    """Return a complete outline for a tracker-guided, partially visible ball disc."""
    angles = np.linspace(0, 2 * math.pi, count, endpoint=False)
    return np.column_stack((center[0] + radius * np.cos(angles), center[1] + radius * np.sin(angles)))


def guided_ball_track(frames, background, seed_radius, motion_track, origin, matrix, distortion, rotation, translation):
    """Recover a short 3D track only where independent image-plane tracking agrees.

    The normal contour path deliberately requires a nearly complete disc. A club,
    seam, or background edge can clip that disc even though the template tracker
    follows the ball cleanly. This fallback lowers the fill gate only at the
    tracker's expected position, then requires three consecutive frames, stable
    apparent radius, and the existing 3D linear-fit gate.
    """
    hints = {}
    for hint in motion_track or []:
        index = hint.get("frameIndex")
        center = np.asarray([hint.get("x"), hint.get("y")], dtype=float)
        if (
            not isinstance(index, int)
            or not 0 <= index < len(frames)
            or not np.all(np.isfinite(center))
            or float(hint.get("score", 0)) < 0.75
            or np.linalg.norm(center - origin) <= seed_radius * 0.5
        ):
            continue
        hints[index] = center

    recovered = []
    for index, expected in sorted(hints.items()):
        candidates = []
        for center, contour in ball_contours(
            frames[index][1], background, seed_radius, minimum_fill=GUIDED_BALL_FILL
        ):
            distance = float(np.linalg.norm(center - expected))
            if distance > seed_radius * 0.5:
                continue
            (_, _), radius = cv2.minEnclosingCircle(contour)
            try:
                camera_center = sphere_center(circle_contour(center, radius), matrix, distortion)
            except ValueError:
                continue
            point = rotation.T @ (camera_center - translation)
            if point[2] < -0.01 or np.linalg.norm(point) > 5:
                continue
            candidates.append((distance, radius, center, point))
        if candidates:
            _, radius, center, point = min(candidates, key=lambda candidate: candidate[0])
            recovered.append({
                "frameIndex": index,
                "positionM": point.tolist(),
                "centerPx": center.tolist(),
                "radiusPx": float(radius),
            })

    runs = []
    for point in recovered:
        if not runs or point["frameIndex"] != runs[-1][-1]["frameIndex"] + 1:
            runs.append([])
        runs[-1].append(point)
    for run in runs:
        for start in range(max(1, len(run) - GUIDED_MIN_SEQUENCE + 1)):
            window = run[start:start + 8]
            if len(window) < GUIDED_MIN_SEQUENCE:
                continue
            radii = [point["radiusPx"] for point in window]
            while len(window) >= GUIDED_MIN_SEQUENCE and max(radii) / min(radii) > GUIDED_RADIUS_RATIO:
                window = window[:-1]
                radii = radii[:-1]
            if len(window) < GUIDED_MIN_SEQUENCE:
                continue
            try:
                velocity, residual = fit_velocity(
                    [frames[point["frameIndex"]][0] for point in window],
                    [point["positionM"] for point in window],
                )
            except ValueError:
                continue
            clean = [{key: value for key, value in point.items() if key != "radiusPx"} for point in window]
            return clean, velocity, residual
    return None


def measure_launch(frames, bounds, impact_index, timestamp_source="host", exposure_us=None, motion_track=None):
    result = {"metrics": unavailable("Needs a calibrated ball/club track."), "ballTrack3d": [], "clubTrack3d": [], "warnings": [], "method": "apriltag-monocular-sphere-v1"}
    metrics = result["metrics"]
    pose_note = None
    def put(key, value, reason, status="estimated"):
        if math.isfinite(value):
            metrics[key] = {"value": round(float(value), 4), "unit": METRICS[key], "status": status, "reason": reason}
    try:
        if timestamp_source != "sensor":
            raise ValueError("Sensor timestamps required; host arrival timing cannot measure launch speed.")
        if len(frames) < 3 or not np.all(np.isfinite([t for t, _ in frames])) or np.any(np.diff([t for t, _ in frames]) <= 0):
            raise ValueError("Capture has missing or non-increasing sensor timestamps.")
        if exposure_us is None or not 0 < exposure_us <= 250:
            raise ValueError("Use fixed exposure at or below 250 us and adequate lighting; faster shots may require shorter exposure.")
        height, width = frames[0][1].shape[:2]
        matrix, distortion = load_setup((width, height))
        ground_id = int(os.getenv("PINPOINT_APRILTAG_ID", "0"))
        tag_size = float(os.getenv("PINPOINT_APRILTAG_SIZE_MM", "100")) / 1000
        pose = find_ground_tag_pose(frames, impact_index, ground_id, tag_size, matrix, distortion)
        if pose is None:
            raise ValueError("Ground AprilTag must be visible in the current burst to establish camera pose.")
        rotation, translation, pose_error = pose["rotation"], pose["translation"], pose["errorPx"]
        result["tagPoseFrameIndex"] = pose["frameIndex"]
        result["tagPoseReprojectionErrorPx"] = round(pose_error, 4)
        if pose_error > MAX_ESTIMATED_TAG_POSE_ERROR_PX:
            raise ValueError(
                f"Ground AprilTag pose reprojection error {pose_error:.2f} px exceeds "
                f"the {MAX_ESTIMATED_TAG_POSE_ERROR_PX:.1f} px estimation limit."
            )
        pose_note = f"Ground-tag pose error {pose_error:.2f} px from frame {pose['frameIndex']}."
        if pose_error > STRICT_TAG_POSE_ERROR_PX:
            result["warnings"].append(
                f"Ground AprilTag pose reprojection error is {pose_error:.2f} px; "
                "launch values are lower-confidence estimates."
            )
        x, y, bw, bh = bounds
        origin = np.array([x + bw / 2, y + bh / 2])
        previous = origin
        track = []
        seed_radius = min(bw, bh) / 2
        background = ball_background(frames, impact_index)
        # The impact hint comes from a coarse presence detector (one sample every
        # frame-stride frames, a removal debounce, and still-present rechecks), so the
        # real departure can sit over a hundred frames either side of it. Locate the
        # first clean moving silhouette anywhere in the burst, then track densely.
        start = 0
        for i in range(0, len(frames), 3):
            if ball_contours(frames[i][1], background, seed_radius):
                start = max(0, i - 3)
                break
        for i in range(start, len(frames)):
            candidates = ball_contours(frames[i][1], background, seed_radius)
            if not candidates:
                continue
            candidates.sort(key=lambda candidate: np.linalg.norm(candidate[0] - previous))
            center, contour = candidates[0]
            # While the ball overlaps its resting spot, or the club head passes over it,
            # the difference blob is not a clean disc; the first accepted silhouette can
            # be a dozen radii out, so only reject candidates that are absurdly far.
            if not track and np.linalg.norm(center - origin) > seed_radius * 40:
                continue
            if track and len(candidates) > 1 and np.linalg.norm(candidates[1][0] - previous) < np.linalg.norm(center - previous) * 1.25:
                continue  # Ambiguous identity: do not silently switch balls.
            try:
                point = rotation.T @ (sphere_center(contour, matrix, distortion) - translation)
            except ValueError:
                continue
            if point[2] < -0.01 or np.linalg.norm(point) > 5:
                continue
            if track and np.linalg.norm(point - np.array(track[-1]["positionM"])) / (frames[i][0] - frames[track[-1]["frameIndex"]][0]) > 100:
                continue
            track.append({"frameIndex": i, "positionM": point.tolist(), "centerPx": center.tolist()})
            previous = center
        outgoing = [p for p in track if np.linalg.norm(np.array(p["centerPx"]) - origin) > seed_radius * .5]
        guided = False
        if len(outgoing) < 3:
            recovered = guided_ball_track(
                frames, background, seed_radius, motion_track, origin,
                matrix, distortion, rotation, translation,
            )
            if recovered is None:
                raise ValueError("Fewer than three unambiguous outgoing ball silhouettes. Increase frame rate/field of view or improve lighting.")
            outgoing, velocity, residual = recovered
            track = outgoing
            guided = True
            result["warnings"].append(
                "Ball outline was reconstructed from a tracker-guided partial silhouette; validate this lower-confidence estimate."
            )
        result["ballTrack3d"] = track
        impact_index = outgoing[0]["frameIndex"]
        result["estimatedImpactFrameIndex"] = impact_index
        launch_track = outgoing[:8]
        if not guided:
            times = [frames[p["frameIndex"]][0] for p in launch_track]
            velocity, residual = fit_velocity(times, [p["positionM"] for p in launch_track])
        speed = float(np.linalg.norm(velocity))
        if not 0.1 <= speed <= 100:
            raise ValueError(f"Ball speed {speed:.1f} m/s is outside the supported 0.1-100 m/s range.")
        if speed * exposure_us / 1e6 > 0.004:
            raise ValueError("Estimated motion blur exceeds 4 mm; shorten exposure for this shot speed.")
        method_note = " Tracker-guided partial-silhouette fallback." if guided else ""
        reason = f"Known-ball-size 3D estimate; fit residual {residual * 1000:.1f} mm.{method_note} Requires reference validation."
        put("ballSpeedMps", speed, reason)
        launch = math.degrees(math.atan2(velocity[2], math.hypot(velocity[0], velocity[1])))
        put("launchAngleDeg", launch, reason)
        # Speed and launch angle do not care which way the tag is rotated; only the
        # start direction needs a reference line, and that is calibrated separately.
        heading = target_heading_rad()
        target = target_rotation(heading)
        if heading is None:
            metrics["startDirectionDeg"]["reason"] = "Set the target line first: roll a ball toward the target, then use Set target line on the Calibration screen."
        else:
            aligned = target @ velocity
            result["targetLineHeadingDeg"] = round(math.degrees(heading), 3)
            put("startDirectionDeg", -math.degrees(math.atan2(aligned[1], aligned[0])), reason)
        put("estimatedCarryM", max(0, speed ** 2 * math.sin(2 * math.radians(launch)) / 9.80665), "Vacuum ballistic estimate to launch height; excludes lift, drag, wind and terrain.")
        measure_spin(frames, outgoing, matrix, distortion, rotation, translation, result, put, target)
        measure_roll(frames, track, result, put)
        measure_club(frames, impact_index, matrix, distortion, rotation, translation, track, result, put)
    except (OSError, ValueError, KeyError, TypeError, cv2.error, np.linalg.LinAlgError) as error:
        result["failure"] = str(error)
        for metric in metrics.values():
            if metric["value"] is None:
                metric["reason"] = str(error)
    for key in ("spinRpm", "spinAxisDeg"):
        if metrics[key]["value"] is None:
            metrics[key]["reason"] = "Needs at least three resolved surface marks and two consistent small-rotation frame pairs; increase magnification/frame rate."
    if metrics["rollDistanceM"]["value"] is None:
        metrics["rollDistanceM"]["reason"] = "Requires continuous in-frame tracking until a verified stop (at least 100 ms)."
    if metrics["skidDistanceM"]["value"] is None:
        metrics["skidDistanceM"]["reason"] = "Requires simultaneous translation and spin tracking through transition to true roll."
    if pose_note:
        for metric in metrics.values():
            if metric["value"] is not None and pose_note not in metric["reason"]:
                metric["reason"] = f"{metric['reason']} {pose_note}"
    return result


def surface_vectors(pixels, center, matrix, distortion):
    rays = cv2.undistortPoints(np.asarray(pixels, np.float64).reshape(-1, 1, 2), matrix, distortion).reshape(-1, 2)
    rays = np.column_stack((rays, np.ones(len(rays))))
    rays /= np.linalg.norm(rays, axis=1)[:, None]
    projection = rays @ center
    discriminant = projection ** 2 - (center @ center - RADIUS ** 2)
    valid = discriminant > 0
    points = rays * (projection - np.sqrt(np.maximum(0, discriminant)))[:, None]
    return (points - center) / RADIUS, valid


def rotation_between(first, second):
    u, _, vh = np.linalg.svd(first.T @ second)
    correction = np.eye(3)
    correction[2, 2] = np.linalg.det(vh.T @ u.T)
    return vh.T @ correction @ u.T


def measure_spin(frames, track, matrix, distortion, world_rotation, world_translation, result, put, target=None):
    target = np.eye(3) if target is None else target
    rates = []
    samples = []
    for first, second in zip(track, track[1:]):
        i, j = first["frameIndex"], second["frameIndex"]
        if j != i + 1:
            continue
        a, b = frames[i][1], frames[j][1]
        if a.ndim == 3:
            a, b = cv2.cvtColor(a, cv2.COLOR_BGR2GRAY), cv2.cvtColor(b, cv2.COLOR_BGR2GRAY)
        ca = world_rotation @ first["positionM"] + world_translation
        cb = world_rotation @ second["positionM"] + world_translation
        radius_px = matrix[0, 0] * RADIUS / ca[2]
        if radius_px < 12:
            continue
        mask = np.zeros_like(a)
        cv2.circle(mask, tuple(np.round(first["centerPx"]).astype(int)), int(radius_px * 0.75), 255, -1)
        features = cv2.goodFeaturesToTrack(a, maxCorners=40, qualityLevel=0.03, minDistance=3, mask=mask)
        if features is None or len(features) < 3:
            continue
        guess = features + np.array(second["centerPx"], np.float32) - np.array(first["centerPx"], np.float32)
        moved, good, _ = cv2.calcOpticalFlowPyrLK(a, b, features, guess, flags=cv2.OPTFLOW_USE_INITIAL_FLOW, winSize=(15, 15), maxLevel=2)
        if moved is None:
            continue
        reverse, back, _ = cv2.calcOpticalFlowPyrLK(b, a, moved, None, winSize=(15, 15), maxLevel=2)
        if reverse is None:
            continue
        va, valid_a = surface_vectors(features, ca, matrix, distortion)
        vb, valid_b = surface_vectors(moved, cb, matrix, distortion)
        valid = good.flatten().astype(bool) & back.flatten().astype(bool) & valid_a & valid_b & (np.linalg.norm(reverse - features, axis=2).flatten() < 0.7)
        va, vb = va[valid], vb[valid]
        if len(va) < 3 or np.linalg.svd(va, compute_uv=False)[-1] < 0.05:
            continue
        rotation = rotation_between(va, vb)
        if np.median(np.linalg.norm(va @ rotation.T - vb, axis=1)) > 0.06:
            continue
        vector = cv2.Rodrigues(rotation)[0].flatten()
        if np.linalg.norm(vector) > math.pi / 3:
            continue  # Ambiguous rotation/feature correspondence at this frame rate.
        rate = target @ world_rotation.T @ vector / (frames[j][0] - frames[i][0])
        rates.append(rate)
        samples.append({"frameIndex": i, "nextFrameIndex": j, "angularVelocityRadS": rate.tolist()})
    result["spinSamples"] = samples
    if len(rates) < 2:
        return
    rate = np.median(rates, axis=0)
    if np.max(np.linalg.norm(np.asarray(rates) - rate, axis=1)) > max(10, np.linalg.norm(rate) * 0.25):
        return
    put("spinRpm", -rate[1] * 60 / (2 * math.pi), "Surface-feature sphere rotation estimate; signed backspin, negative for topspin.")
    put("spinAxisDeg", math.degrees(math.atan2(rate[2], -rate[1])), "Spin axis from tracked surface marks; positive sidespin curves left.")


def measure_roll(frames, track, result, put):
    if len(track) < 5:
        return
    positions = np.asarray([p["positionM"] for p in track])
    indexes = [p["frameIndex"] for p in track]
    times = np.array([frames[i][0] for i in indexes])
    if np.any(np.diff(indexes) != 1) or np.max(np.abs(positions[:, 2] - RADIUS)) > .008:
        return
    stopped = times >= times[-1] - .1
    if np.count_nonzero(stopped) >= 3 and times[-1] - times[stopped][0] >= .09 and np.ptp(positions[stopped], axis=0).max() < .003:
        put("rollDistanceM", np.linalg.norm(positions[-1, :2] - positions[0, :2]), "Estimated straight-line ground distance from stationary placement to observed stop.")
    rolling_streak = 0
    for sample in result.get("spinSamples", []):
        i = sample["frameIndex"]
        if i not in indexes or sample["nextFrameIndex"] not in indexes:
            rolling_streak = 0
            continue
        n = indexes.index(i)
        if n + 1 >= len(track):
            continue
        velocity = (positions[n + 1] - positions[n]) / (times[n + 1] - times[n])
        omega = np.array(sample["angularVelocityRadS"])
        slip = np.linalg.norm((velocity + np.cross(omega, [0, 0, -RADIUS]))[:2])
        rolling_streak = rolling_streak + 1 if slip < max(.03, np.linalg.norm(velocity[:2]) * .1) else 0
        if rolling_streak >= 3:
            put("skidDistanceM", np.linalg.norm(positions[max(0, n - 2), :2] - positions[0, :2]), "Estimated ground displacement before three consecutive low-slip surface-rotation pairs.")
            break


def measure_club(frames, impact_index, matrix, distortion, world_rotation, world_translation, ball_track, result, put):
    path = Path(os.getenv("PINPOINT_CLUB_MARKER_PATH", "/var/lib/pinpoint/club-marker.json"))
    if not path.exists():
        for key in ("clubSpeedMps", "smashFactor", "strikeXmm", "strikeYmm"):
            result["metrics"][key]["reason"] = "Attach a club AprilTag and calibrate its rigid transform to the face center."
        return
    config = json.loads(path.read_text())
    result["clubId"] = config.get("clubId")
    center = np.asarray(config["faceCenterM"], float)
    axes = np.asarray(config["faceAxes"], float)  # columns: toe, high, outward normal
    if center.shape != (3,) or axes.shape != (3, 3) or not np.allclose(axes.T @ axes, np.eye(3), atol=0.001) or np.linalg.det(axes) < .999 or not np.all(np.isfinite(center)):
        raise ValueError("Invalid club face transform.")
    if config["tagSizeMm"] <= 0 or config["tagId"] == int(os.getenv("PINPOINT_APRILTAG_ID", "0")):
        raise ValueError("Club tag must have positive size and a different ID from the ground tag.")
    club = []
    for i in range(max(0, impact_index - 16), impact_index + 1):
        tags = marker_map(frames[i][1])
        if config["tagId"] not in tags:
            continue
        rotation, translation = tag_pose(tags[config["tagId"]], config["tagSizeMm"] / 1000, matrix, distortion)
        world_center = world_rotation.T @ (rotation @ center + translation - world_translation)
        world_axes = world_rotation.T @ rotation @ axes
        club.append((i, world_center, world_axes))
    result["clubTrack3d"] = [{"frameIndex": i, "positionM": p.tolist()} for i, p, _ in club]
    if len(club) < 3:
        raise ValueError("Club tag needs at least three resolved pre-impact poses.")
    last = club[-5:]
    velocity, _ = fit_velocity([frames[i][0] for i, _, _ in last], [p for _, p, _ in last])
    speed = float(np.linalg.norm(velocity))
    if not 0.1 < speed < 80:
        raise ValueError("Club speed is outside supported range.")
    put("clubSpeedMps", speed, "Rigid club-tag pose and calibrated face-center offset.")
    put("smashFactor", result["metrics"]["ballSpeedMps"]["value"] / speed, "Ratio of estimated ball and club speeds.")
    stationary = [p for p in ball_track if p["frameIndex"] < impact_index]
    if not stationary:
        return
    ball = np.median([p["positionM"] for p in stationary], axis=0)
    i, face, axes = last[-1]
    # Extrapolate for at most one sensor interval; reject unsupported contact geometry.
    dt = frames[impact_index][0] - frames[i][0]
    if dt < 0 or dt > 0.01:
        return
    relative = axes.T @ (ball - (face + velocity * dt))
    if abs(abs(relative[2]) - RADIUS) > 0.01 or abs(relative[0]) > 0.06 or abs(relative[1]) > 0.04:
        return
    put("strikeXmm", relative[0] * 1000, "Club-face contact estimate at ball departure; verify with impact tape.")
    put("strikeYmm", relative[1] * 1000, "Club-face contact estimate at ball departure; verify with impact tape.")
