# LM1 enclosure CAD

Enclosure version **0.4.0**

This folder contains a narrow, flat-pack enclosure for the LM1 Raspberry Pi 5
launch monitor. Version 0.4.0 is an engineering prototype intended to verify
placement, camera framing, cooling and service access before cosmetic refinement.
The earlier v0.2.0 and v0.3.0 files remain available for comparison.

## Geometry represented by the model

- Lens centre is 150 mm above the hitting surface.
- The OV9281 plate is pitched 13 degrees downward.
- The assembled body is 174 x 144 x 189 mm, excluding the removable hood.
- The enclosure is placed approximately 500 mm downrange and 300 mm on the
  toe side of the ball, then aimed inward at the hitting area.
- The camera hood clears an approximately 100-degree horizontal field of view.
- Two generic 28 mm LED openings sit below the camera hood.
- A replaceable 3 mm polycarbonate window is clamped behind the camera opening.
- Raspberry Pi 5 mounting bosses use the standard 58 x 49 mm hole pattern.
- A generic 2.79-inch, 16:9 OLED sits in a separate display pod.
- The OLED face is tilted 35 degrees above horizontal.
- The OLED pod swivels 35 degrees left or right and locks with two M3 screws.
- A rear 40 mm fan pattern and side ventilation slots provide active airflow.
- Flat panels are clamped between a base, top and four universal corner rails.

## Generated files

The `stl/v0.4.0` directory contains:

- `lm1_base_v0.4.0.stl` - floor with Pi 5 bosses and ballast holes
- `lm1_front_sensor_panel_v0.4.0.stl` - replaceable camera/LED panel
- `lm1_rear_service_panel_v0.4.0.stl` - fan and cable-access panel
- `lm1_side_panel_v0.4.0.stl` - reversible ventilated panel; print two
- `lm1_corner_rail_v0.4.0.stl` - universal screw rail; print four
- `lm1_top_swivel_v0.4.0.stl` - removable roof with cable and swivel slots
- `lm1_oled_swivel_base_v0.4.0.stl` - rotating OLED base and cable collar
- `lm1_oled_tilt_cradle_35deg_v0.4.0.stl` - angled OLED bezel and supports
- `lm1_oled_retainer_v0.4.0.stl` - rear display clamp
- `lm1_sun_hood_v0.4.0.stl` - camera glare and sun hood
- `lm1_camera_mount_13deg_v0.4.0.stl` - adjustable OV9281 board plate
- `lm1_window_retainer_v0.4.0.stl` - clamp for the polycarbonate window
- `lm1_led_adapter_v0.4.0.stl` - generic LED adapter; print two
- `lm1_assembly_reference_v0.4.0.stl` - assembled reference, not for printing

## Important fit assumptions

The OLED dimensions are provisional because "2.79 inch" describes only its
diagonal, not the PCB or mounting holes. Version 0.2.0 assumes:

| Item | Assumed size |
| --- | --- |
| OLED visible opening | 65 x 37 mm |
| OLED PCB pocket | 80 x 48 mm |
| OLED mounting pattern | 72 x 42 mm, M2.5 |
| OV9281 board | up to 54 x 54 mm |
| OV9281 mounting slots | 24-34 mm centres, M2.5 |
| LED body opening | 28 mm |
| Fan | 40 mm, 32 mm mounting pattern |

Measure the exact OLED and camera board before committing to a long print.
The values are grouped at the top of `lm1_case_v0_2_0.py` for easy editing.

## Hardware

- 4 x M2.5 screws for Raspberry Pi 5
- 4 x M2.5 screws and nuts for the OLED retainer
- 4 x M3 screws for the camera mount
- 4 x M3 screws for the window retainer
- 4 x M3 screws for the sun hood
- 24 x M3 screws for the panels, rails, base and top
- 2 x M3 screws and lock nuts for the OLED swivel slots
- 4 x M3 screws for attaching the tilted cradle to its swivel base
- 4 x M3 screws for an optional 40 mm fan
- 90 x 68 x 3 mm clear polycarbonate camera window
- Heat-set inserts are recommended for repeatedly removed parts
- Rubber feet and a steel ballast plate are recommended for stability

Do not use acrylic for the protective window. A golf-ball impact can shatter
acrylic; polycarbonate is the safer sacrificial material. This prototype has
not been impact certified, so it must remain outside the intended ball line.

## Printing

- Material: ASA is preferred outdoors; PETG is the easier prototype material.
- Walls: 4 perimeters.
- Layer height: 0.20 mm.
- Infill: 25-35 percent, with 45 percent around the camera bracket.
- Every v0.3.0 part fits within 180 x 174 mm on the print bed.
- Print the base and all panels flat.
- Print four corner rails horizontally and two copies of the side panel.
- Print the hood on either side wall to avoid a long unsupported bridge.
- The OLED swivel base STL is already oriented with its main plate on the bed.
- Print the OLED tilt cradle on one triangular side support.
- Print the retainers flat.
- Use supports only for the camera mount if the slicer cannot bridge its arms.

## Regenerate the STL files

```powershell
python -m pip install -r hardware/enclosure/requirements-cad.txt
python hardware/enclosure/lm1_case_v0_4_0.py
```

After changing camera or display geometry, increment `CASE_VERSION` and the
output folder before exporting another revision.
