"""Version 1.0.0: separate visible ball movement from evidence of a swing."""


def shot_evidence(measurements):
    diagnostics = measurements.get("diagnostics") or {}
    silhouette = diagnostics.get("clubSilhouette")
    tagged = measurements.get("clubTrack3d") or []
    if silhouette is None and not tagged and "diagnostics" not in measurements:
        return measurements.get("shotEvidence")
    frames = max(len(tagged), (silhouette or {}).get("acceptedFrames", 0))
    observed = frames >= 3
    return {
        "status": "club-motion-observed" if observed else "motion-only",
        "clubFrames": frames,
        "reason": (f"Club motion near the ball tracked in {frames} frames. Contact remains inferred."
                   if observed else "Ball movement without a resolved pre-impact club track; review this capture instead of counting a swing."),
    }
