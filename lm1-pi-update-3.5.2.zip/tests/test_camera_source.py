import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from camera_source import CsiCapture, camera_diagnostics, clear_camera_diagnostics, record_camera_diagnostics
from pinpoint_protocol import PinpointProtocol, build_preview_event


class CsiCameraTests(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {
            "PINPOINT_CAMERA_SOURCE": "csi", "PINPOINT_EXPOSURE_US": "0",
            "PINPOINT_CAMERA_RESOLUTION": "1280x800", "PINPOINT_CAMERA_FPS": "30",
            "PINPOINT_CAPTURE_BACKEND": "simulator", "PINPOINT_BLE_PREVIEW": "true",
        }, clear=True)
        self.env.start()
        clear_camera_diagnostics()

    def tearDown(self):
        clear_camera_diagnostics()
        self.env.stop()

    def test_status_requires_live_frames_not_device_node(self):
        protocol = PinpointProtocol(MagicMock())
        self.assertFalse(protocol.status()["cameraConnected"])
        self.assertEqual(protocol.status()["preview"]["height"], 100)
        record_camera_diagnostics({"model": "ov9281", "fps": 30.0, "exposureUs": 18000})
        status = protocol.status()
        self.assertTrue(status["cameraConnected"])
        self.assertEqual(status["exposureUs"], 18000)
        self.assertEqual(status["captureBackend"], "simulator")
        with patch("camera_source.time.monotonic", return_value=10**12):
            self.assertFalse(protocol.status()["cameraConnected"])

    def test_preview_carries_live_focus_and_exposure(self):
        record_camera_diagnostics({"model": "ov9281", "focusScore": 24.2, "exposureUs": 10000})
        self.assertEqual(build_preview_event(b"jpeg")["data"]["camera"]["focusScore"], 24.2)

    def test_capture_returns_full_frame_and_releases_request(self):
        camera = MagicMock()
        camera.camera_properties = {"Model": "ov9281"}
        camera.camera_controls = {"ExposureTime": (), "AeEnable": ()}
        request = camera.wait.return_value
        request.make_array.return_value = SimpleNamespace(shape=(800, 1280, 3))
        request.get_metadata.return_value = {"FrameDuration": 33333, "ExposureTime": 20000}
        with patch.dict(sys.modules, {"picamera2": SimpleNamespace(Picamera2=MagicMock(return_value=camera))}):
            capture = CsiCapture()
            self.assertTrue(camera.create_video_configuration.call_args.kwargs["controls"]["AeEnable"])
            self.assertTrue(capture.read()[0])
            request.release.assert_called_once()
            self.assertEqual(camera_diagnostics()["width"], 1280)
            self.assertFalse(camera_diagnostics()["autofocus"])
            capture.release()
        camera.close.assert_called_once()
        self.assertEqual(camera_diagnostics(), {})

    def test_timeout_cancels_pending_capture_and_allows_cleanup(self):
        camera = MagicMock()
        camera.wait.side_effect = TimeoutError
        with patch.dict(sys.modules, {"picamera2": SimpleNamespace(Picamera2=MagicMock(return_value=camera))}):
            capture = CsiCapture()
            with self.assertRaisesRegex(RuntimeError, "stopped delivering"):
                capture.read()
            capture.release()
        camera.cancel_all_and_flush.assert_called_once()
        camera.close.assert_called_once()

    def test_configuration_failure_closes_camera(self):
        camera = MagicMock()
        camera.configure.side_effect = RuntimeError("configuration failed")
        with patch.dict(sys.modules, {"picamera2": SimpleNamespace(Picamera2=MagicMock(return_value=camera))}):
            with self.assertRaisesRegex(RuntimeError, "configuration failed"):
                CsiCapture()
        camera.close.assert_called_once()
