"""CSI camera ownership and live diagnostics, independent of shot simulation."""

from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path
from typing import Any

MIN_EXPOSURE_US = 50
MAX_EXPOSURE_US = 250
EXPOSURE_STEP_US = 10
DEFAULT_CAMERA_SETTINGS_PATH = Path("/var/lib/pinpoint/camera-settings.json")

_lock = threading.Lock()
_live: dict[str, Any] = {}
_updated = 0.0
_active_capture: CsiCapture | None = None


def uses_csi() -> bool:
    return os.getenv("PINPOINT_CAMERA_SOURCE", "usb").lower() == "csi"


def camera_diagnostics() -> dict[str, Any]:
    with _lock:
        return dict(_live) if time.monotonic() - _updated < 5 else {}


def clear_camera_diagnostics() -> None:
    global _updated
    with _lock:
        _live.clear()
        _updated = 0.0


def record_camera_diagnostics(values: dict[str, Any]) -> None:
    global _updated
    with _lock:
        _live.update(values)
        _updated = time.monotonic()


def _settings_path() -> Path:
    return Path(os.getenv("PINPOINT_CAMERA_SETTINGS_PATH", str(DEFAULT_CAMERA_SETTINGS_PATH)))


def configured_exposure_us() -> int:
    """Return the persisted manual exposure, falling back to the service environment."""
    try:
        saved = json.loads(_settings_path().read_text(encoding="utf-8"))
        exposure = saved.get("exposureUs") if isinstance(saved, dict) else None
        if isinstance(exposure, int) and not isinstance(exposure, bool) and exposure > 0:
            return exposure
    except (OSError, ValueError):
        pass
    return int(os.getenv("PINPOINT_EXPOSURE_US", "0"))


def exposure_configuration() -> dict[str, Any]:
    return {
        "configurable": uses_csi(),
        "minUs": MIN_EXPOSURE_US,
        "maxUs": MAX_EXPOSURE_US,
        "stepUs": EXPOSURE_STEP_US,
    }


def _save_exposure_us(exposure_us: int) -> None:
    path = _settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps({"exposureUs": exposure_us}, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def set_camera_exposure(exposure_us: int) -> dict[str, Any]:
    """Apply and persist a measurement-safe manual exposure on the active CSI camera."""
    if isinstance(exposure_us, bool) or not isinstance(exposure_us, int):
        raise ValueError("Exposure must be a whole number of microseconds.")
    if not MIN_EXPOSURE_US <= exposure_us <= MAX_EXPOSURE_US:
        raise ValueError(f"Exposure must be between {MIN_EXPOSURE_US} and {MAX_EXPOSURE_US} μs.")
    with _lock:
        capture = _active_capture
    if capture is None or not capture.isOpened():
        raise RuntimeError("The CSI camera is not ready for exposure changes.")

    previous = capture.exposure_us
    capture.set_exposure(exposure_us)
    try:
        _save_exposure_us(exposure_us)
    except OSError:
        capture.set_exposure(previous)
        raise
    return {"exposureUs": exposure_us, **exposure_configuration()}


class CsiCapture:
    """Picamera2 adapter returning OpenCV-compatible images from one owned stream."""

    def __init__(self) -> None:
        from picamera2 import Picamera2

        self.camera = None
        self.metadata: dict[str, Any] = {}
        width, height = map(int, os.getenv("PINPOINT_CAMERA_RESOLUTION", "1280x800").split("x"))
        fps = float(os.getenv("PINPOINT_CAMERA_FPS", "30"))
        if width <= 0 or height <= 0 or fps <= 0:
            raise ValueError("Camera dimensions and frame rate must be positive")
        camera = Picamera2(int(os.getenv("PINPOINT_CAMERA_INDEX", "0")))
        try:
            controls: dict[str, Any] = {"FrameRate": fps, "AeEnable": True}
            exposure = configured_exposure_us()
            if exposure > 0:
                controls.update(AeEnable=False, ExposureTime=exposure,
                                AnalogueGain=float(os.getenv("PINPOINT_CAMERA_GAIN", "1")))
            config = camera.create_video_configuration(
                main={"size": (width, height), "format": "RGB888"},
                sensor={"output_size": (width, height), "bit_depth": 10},
                controls=controls, buffer_count=4,
            )
            camera.configure(config)
            camera.start()
            self.model = str(camera.camera_properties.get("Model", "CSI camera"))
            self.exposure_us = exposure
            self.camera = camera
            global _active_capture
            with _lock:
                _active_capture = self
        except Exception:
            camera.close()
            raise

    def isOpened(self) -> bool:
        return self.camera is not None

    def set_exposure(self, exposure_us: int) -> None:
        if self.camera is None:
            raise RuntimeError("The CSI camera is not open.")
        controls: dict[str, Any] = {"AeEnable": exposure_us <= 0}
        if exposure_us > 0:
            controls.update(
                ExposureTime=exposure_us,
                AnalogueGain=float(os.getenv("PINPOINT_CAMERA_GAIN", "1")),
            )
        self.camera.set_controls(controls)
        self.exposure_us = exposure_us
        record_camera_diagnostics({
            "exposureUs": exposure_us,
            "autoExposure": exposure_us <= 0,
        })

    def read(self) -> tuple[bool, Any]:
        if self.camera is None:
            return False, None
        job = self.camera.capture_request(wait=False)
        try:
            request = self.camera.wait(job, timeout=2)
        except TimeoutError:
            self.camera.cancel_all_and_flush()
            raise RuntimeError("CSI camera stopped delivering frames") from None
        try:
            frame = request.make_array("main")
            self.metadata = request.get_metadata()
            duration = self.metadata.get("FrameDuration", 0)
            record_camera_diagnostics({
                "model": self.model, "width": frame.shape[1], "height": frame.shape[0],
                "fps": round(1_000_000 / duration, 1) if duration else 0,
                "exposureUs": self.metadata.get("ExposureTime", 0),
                "gain": round(self.metadata.get("AnalogueGain", 1), 2),
                "autoExposure": self.exposure_us <= 0,
                "autofocus": "AfMode" in self.camera.camera_controls,
            })
            return True, frame
        finally:
            request.release()

    def release(self) -> None:
        global _active_capture
        with _lock:
            if _active_capture is self:
                _active_capture = None
        if self.camera is not None:
            camera, self.camera = self.camera, None
            try:
                camera.stop()
            finally:
                camera.close()
        clear_camera_diagnostics()
