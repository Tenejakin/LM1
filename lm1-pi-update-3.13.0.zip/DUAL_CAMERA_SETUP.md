# Dual OV9281 setup — v1.0.0

App 3.13.0 / build 49 · Pi service 0.30.0 · protocol 2.20.0.

## Enclosure and camera roles

This profile follows the latest vertical enclosure v0.7.2. The user confirmed
that **CAM0 is the lower camera**. It detects the ball and triggers both saved
views. CAM1 is the upper camera. The stand's nominal lens heights are 162.5 mm
and 247.5 mm, its vertical baseline is 85 mm, and both cameras point down 18°.
These CAD dimensions are mounting references, not measured stereo calibration.

1. Keep both lenses parallel in the carrier. Aim the whole enclosure so the
   ball and its initial path are visible in both previews.
2. Turn on the hitting-area illumination. Both views were still very dark at
   the saved short shutter setting during the installation checks.
3. Reload app 3.13.0 and connect. Device shows the lower placement preview,
   upper preview, matched frame rate and timing status. Use the existing shutter
   and brightness controls; both cameras receive the same settings. Automatic
   brightness uses the lower view, so also inspect the upper view for clipping.
4. Put a printed target at ball distance and focus each lens manually. The
   existing numeric sharpness score refers to the lower view only.
5. Remove the ball and hands, then reset the empty background after aiming or
   changing lighting. Place a ball in the lower preview's detection region.
   When it departs, both views are saved under one capture ID. The upper view
   accompanies the initial capture image and matching replay frames.

## Capture settings and timing

- Two OV9281 streams at **640×400, requested 242 fps, 10-bit sensor mode**.
- CAM0 is the software timing server; CAM1 is the client. Each sensor is drained
  independently into a bounded queue. Frames are paired using SensorTimestamp.
- Each accepted pair must be within 250 μs. Missing cameras, missing timestamps
  or failure to acquire timing lock fail acquisition; they do not silently
  produce a single-camera capture in dual mode.
- SyncReady is intermittent libcamera metadata. Its last explicit value is
  retained, while timestamp differences are checked on every frame pair.
- Existing short shutter/gain settings and ball detection thresholds are retained.
- Existing buffer settings retain 325 frames per camera, about 1.34 seconds at
  the verified rate. Sensor timestamps retain any frame gaps.
- This is **software synchronization**. It does not establish externally
  validated exposure timing or calibrated stereo 3D measurements. The existing
  measurement pipeline still uses the lower camera. Lens/stereo calibration and
  physical validation are separate work before using both views for 3D metrics.

Raspberry Pi's [software synchronization documentation](https://www.raspberrypi.com/documentation/computers/camera_software.html#software-camera-synchronisation)
explains why spare sensor frame-rate capacity is needed for timing corrections.

## Verification on this Pi, 2026-09-22

- Both sensors open concurrently and deliver distinct image data.
- At requested 242 fps, a saved real burst contained 325 frames per camera at
  241.57 observed paired fps. Maximum timestamp offset: 40 μs.
- A 30-second run of the full detector and preview pipeline produced 4,832 paired
  frames in its final 20-second measurement window: 241.56 observed fps,
  maximum offset 54 μs, maximum adjacent-frame gap 4.189 ms. Nine previews
  contained both camera images. No physical shot was performed in this check.
- 243, 244 and 245 fps in 10-bit mode stalled during startup. At 280 and 300 fps
  in 8-bit mode, the pair failed the 250 μs timing gate. Requested 242 fps was
  therefore the fastest tested setting that passed the capture checks.
- Old one-camera captures remain readable. New captures place upper frames in
  `camera-secondary/` with their own manifest/contact sheet. The main
  `capture.json` records both camera indexes and each pair's timestamp offset.
- Stereo calibration is explicitly marked unavailable. Upper frames do not
  inherit the lower camera's saved AprilTag calibration.
- 197 Python tests passed on the Pi with test calibration/storage paths isolated
  from production data. App type checking, lint and the fragmented BLE client
  integration check passed. Phone rendering/reception and a physical golf strike
  have not been verified in this setup session.
- The deployed service restarted successfully with zero automatic restarts;
  both snapshot files update and the detector reaches waiting-for-ball state.

## Installation and rollback

The Pi boot camera configuration is v0.2.0, with both `dtoverlay=ov9281,cam0`
and `dtoverlay=ov9281`. The existing SSH connection is
`lm1@192.168.0.140`, using `~/.ssh/lm1_codex_ed25519` on the Windows host.

The normal Pi installer includes the updated camera modules and preserves
existing environment settings. To enable the verified profile on this already
provisioned Pi, copy the service folder and run:

```sh
sudo python3 scripts/setup-dual-camera-v1.0.0.py raspberry_pi
```

The setup script backs up the four changed service files, environment and boot
configuration under `/var/lib/pinpoint/backups/pre-dual-0.30.0-*` before replacing
service files. It sets `PINPOINT_DUAL_CAMERA=true`, primary index 0, secondary
index 1, requested 242 fps and 10-bit mode. It restarts the service.

To return to one camera, set `PINPOINT_DUAL_CAMERA=false` in
`/etc/default/pinpoint` and restart `pinpoint`. To roll back code, stop the
service, restore the four Python files and `pinpoint.env` from the printed
backup location, then start it. The second boot overlay can remain enabled.

The diagnostic scripts must run while the service is stopped, with a shell
trap to restart it on exit. Hardware test captures live separately from shot
history in `/home/lm1/dual-camera-0.30.0/`.
