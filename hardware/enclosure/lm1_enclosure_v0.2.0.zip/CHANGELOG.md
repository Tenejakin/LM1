# LM1 enclosure changelog

## 0.2.0 - 2026-09-04

- Added a printable Raspberry Pi 5 chassis with standard mounting bosses.
- Fixed the camera optical centre at 150 mm and the camera plate at 13 degrees downward.
- Added a removable wide-angle sun hood and replaceable window retainer.
- Added a removable top with a provisional 2.79-inch OLED opening and clamp.
- Added dual LED apertures, a 40 mm rear fan pattern and cross-flow vents.
- Exported separate watertight STL parts and an assembly reference.
