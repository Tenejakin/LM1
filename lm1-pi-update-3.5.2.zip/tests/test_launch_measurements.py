import json
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from launch_measurements import RADIUS, fit_velocity, load_setup, measure_club, measure_launch, measure_roll, rotation_between, sphere_center, surface_vectors, tag_pose, unavailable
from ball_detector import RollingFrameBuffer


class GeometryTests(unittest.TestCase):
    def setUp(self):
        self.matrix = np.array([[800., 0, 640], [0, 800, 400], [0, 0, 1]])
        self.distortion = np.zeros(5)

    def test_off_axis_sphere_recovers_known_depth(self):
        center = np.array([0.15, 0.07, 0.8])
        axis = center / np.linalg.norm(center)
        first = np.cross(axis, [0, 1, 0]); first /= np.linalg.norm(first)
        second = np.cross(axis, first)
        angle = np.arcsin(RADIUS / np.linalg.norm(center))
        contour = []
        for phi in np.linspace(0, 2 * np.pi, 100, endpoint=False):
            ray = axis * np.cos(angle) + (first * np.cos(phi) + second * np.sin(phi)) * np.sin(angle)
            pixel = self.matrix @ ray
            contour.append(pixel[:2] / pixel[2])
        np.testing.assert_allclose(sphere_center(contour, self.matrix, self.distortion), center, atol=1e-6)

    def test_tag_pose_and_world_axes_round_trip(self):
        points = np.array([[0., 0, 0], [.1, 0, 0], [.1, -.1, 0], [0, -.1, 0]])
        rotation = np.array([2.6, 0.1, 0.2])
        translation = np.array([0.1, -0.05, 0.8])
        corners = cv2.projectPoints(points, rotation, translation, self.matrix, self.distortion)[0].reshape(4, 2)
        r, t = tag_pose(corners, .1, self.matrix, self.distortion)
        np.testing.assert_allclose(t, translation, atol=1e-6)
        np.testing.assert_allclose(r, cv2.Rodrigues(rotation)[0], atol=1e-6)

    def test_velocity_uses_nonuniform_actual_times(self):
        times = np.array([1, 1.005, 1.011, 1.016])
        expected = np.array([40., -2., 10.])
        velocity, error = fit_velocity(times, (times - times[0])[:, None] * expected + [0, 0, .03])
        np.testing.assert_allclose(velocity, expected, atol=1e-9)
        self.assertLess(error, 1e-9)

    def test_bad_timestamps_and_tracks_are_rejected(self):
        with self.assertRaises(ValueError): fit_velocity([0, 0, .01], np.zeros((3, 3)))
        with self.assertRaises(ValueError): fit_velocity([0, .005, .01], [[0, 0, 0], [1, 1, 1], [.1, 0, 0]])

    def test_surface_rotation_recovers_known_rotation(self):
        first = np.array([[.1, .2, -.97], [-.3, .1, -.95], [.2, -.4, -.89], [-.3, -.3, -.9]])
        first /= np.linalg.norm(first, axis=1)[:, None]
        expected = cv2.Rodrigues(np.array([.05, -.2, .03]))[0]
        np.testing.assert_allclose(rotation_between(first, first @ expected.T), expected, atol=1e-9)

    def test_center_ray_hits_front_ball_surface(self):
        vectors, valid = surface_vectors([[640, 400]], np.array([0, 0, .8]), self.matrix, self.distortion)
        self.assertTrue(valid[0])
        np.testing.assert_allclose(vectors[0], [0, 0, -1], atol=1e-8)

    def test_sensor_metadata_retained_with_ring(self):
        buffer = RollingFrameBuffer(2)
        for i in range(3):
            buffer.append(np.zeros((20, 20), np.uint8), metadata={'SensorTimestamp': 1_000_000_000 + i * 5_000_000, 'ExposureTime': 50})
        self.assertEqual(buffer.timestamp_source, 'sensor')
        self.assertAlmostEqual(buffer.frames[-1][0] - buffer.frames[0][0], .005)
        buffer.clear()
        self.assertEqual(buffer.timestamp_source, 'host')

    def test_calibration_resolution_mismatch_rejected(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / 'intrinsics.json'
            path.write_text(json.dumps({'imageSize': [1280, 800], 'cameraMatrix': self.matrix.tolist(), 'distCoeffs': [0]*5, 'rmsPx': .2}))
            with patch.dict(os.environ, {'PINPOINT_INTRINSICS_PATH': str(path)}):
                load_setup((1280, 800))
                with self.assertRaises(ValueError): load_setup((640, 400))

    def test_host_timing_never_returns_physical_metrics(self):
        result = measure_launch([(0, np.zeros((20, 20), np.uint8))], (2, 2, 10, 10), 0)
        self.assertTrue(all(metric['value'] is None for metric in result['metrics'].values()))
        self.assertIn('Sensor timestamps', result['failure'])

    def test_rendered_ball_burst_produces_launch_estimate(self):
        rotation = np.diag([1., -1., -1.])
        translation = np.array([0., 0., .8])
        tag_points = np.array([[0., 0, 0], [.1, 0, 0], [.1, -.1, 0], [0, -.1, 0]])
        corners = cv2.projectPoints(tag_points, cv2.Rodrigues(rotation)[0], translation, self.matrix, self.distortion)[0].reshape(4, 2)
        frames = []
        for i in range(18):
            elapsed = max(0, i - 7) * .005
            world = np.array([.05 + elapsed * 3, -.05, RADIUS + elapsed * .5])
            camera = rotation @ world + translation
            pixel = self.matrix @ camera; pixel = pixel[:2] / pixel[2]
            frame = np.full((800, 1280), 30, np.uint8)
            cv2.circle(frame, tuple(np.round(pixel * 16).astype(int)), round(800 * RADIUS / camera[2] * 16), 230, -1, shift=4)
            frames.append((1 + i * .005, frame))
        with TemporaryDirectory() as directory:
            path = Path(directory) / 'intrinsics.json'
            path.write_text(json.dumps({'imageSize': [1280, 800], 'cameraMatrix': self.matrix.tolist(), 'distCoeffs': [0]*5, 'rmsPx': .2}))
            with patch.dict(os.environ, {'PINPOINT_INTRINSICS_PATH': str(path), 'PINPOINT_CLUB_MARKER_PATH': str(Path(directory) / 'absent.json')}), patch('launch_measurements.marker_map', return_value={0: corners}):
                result = measure_launch(frames, (669, 429, 45, 45), 8, 'sensor', 50)
        value = result['metrics']['ballSpeedMps']['value']
        self.assertIsNotNone(value, result.get('failure'))
        self.assertAlmostEqual(value, np.hypot(3, .5), delta=.25)
        self.assertIsNone(result['metrics']['clubSpeedMps']['value'])
        self.assertEqual(result['metrics']['ballSpeedMps']['status'], 'estimated')

    def test_club_pose_speed_and_face_contact_geometry(self):
        frames = [(i * .005, np.zeros((800, 1280), np.uint8)) for i in range(7)]
        ground_translation = np.array([0., 0., 1.])
        marker_points = np.array([[0., 0, 0], [.02, 0, 0], [.02, -.02, 0], [0, -.02, 0]])
        maps = []
        for i in range(7):
            face = np.array([.1 - RADIUS - (6 - i) * .005 * 2, 0, .1])
            corners = cv2.projectPoints(marker_points, np.zeros(3), face + ground_translation, self.matrix, self.distortion)[0].reshape(4, 2)
            maps.append({1: corners})
        metrics = unavailable('fixture'); metrics['ballSpeedMps']['value'] = 3
        result = {'metrics': metrics}
        def put(key, value, reason): metrics[key].update(value=value, reason=reason)
        with TemporaryDirectory() as directory:
            path = Path(directory) / 'club.json'
            path.write_text(json.dumps({'clubId': 'driver', 'tagId': 1, 'tagSizeMm': 20, 'faceCenterM': [0,0,0], 'faceAxes': [[0,0,1],[1,0,0],[0,1,0]]}))
            with patch.dict(os.environ, {'PINPOINT_CLUB_MARKER_PATH': str(path)}), patch('launch_measurements.marker_map', side_effect=maps):
                measure_club(frames, 6, self.matrix, self.distortion, np.eye(3), ground_translation,
                             [{'frameIndex': 0, 'positionM': [.1, 0, .1]}], result, put)
        self.assertAlmostEqual(metrics['clubSpeedMps']['value'], 2, places=5)
        self.assertAlmostEqual(metrics['smashFactor']['value'], 1.5, places=5)
        self.assertAlmostEqual(metrics['strikeXmm']['value'], 0, places=4)
        self.assertAlmostEqual(metrics['strikeYmm']['value'], 0, places=4)

    def test_putt_stop_and_rolling_transition(self):
        frames = [(i * .01, None) for i in range(31)]
        track = [{'frameIndex': i, 'positionM': [min(i, 15) * .01, 0, RADIUS]} for i in range(31)]
        result = {'metrics': unavailable('fixture'), 'spinSamples': [
            {'frameIndex': i, 'nextFrameIndex': i+1, 'angularVelocityRadS': [0, 1/RADIUS, 0]} for i in range(3)]}
        def put(key, value, reason): result['metrics'][key].update(value=value, reason=reason)
        measure_roll(frames, track, result, put)
        self.assertAlmostEqual(result['metrics']['rollDistanceM']['value'], .15)
        self.assertAlmostEqual(result['metrics']['skidDistanceM']['value'], 0)


if __name__ == '__main__': unittest.main()
