"""CSI camera ownership and live diagnostics, independent of shot simulation."""

from __future__ import annotations

import os
import threading
import time
from typing import Any

_lock = threading.Lock()
_live: dict[str, Any] = {}
_updated = 0.0


def uses_csi() -> bool:
    return os.getenv("PINPOINT_CAMERA_SOURCE", "usb").lower() == "csi"


def camera_diagnostics() -> dict[str, Any]:
    with _lock:
        return dict(_live) if time.monotonic() - _updated < 5 else {}


def clear_camera_diagnostics() -> None:
    global _updated
    with _lock:
        _live.clear()
        _updated = 0.0


def record_camera_diagnostics(values: dict[str, Any]) -> None:
    global _updated
    with _lock:
        _live.update(values)
        _updated = time.monotonic()


class CsiCapture:
    """Picamera2 adapter returning OpenCV-compatible images from one owned stream."""

    def __init__(self) -> None:
        from picamera2 import Picamera2

        self.camera = None
        self.metadata: dict[str, Any] = {}
        width, height = map(int, os.getenv("PINPOINT_CAMERA_RESOLUTION", "1280x800").split("x"))
        fps = float(os.getenv("PINPOINT_CAMERA_FPS", "30"))
        if width <= 0 or height <= 0 or fps <= 0:
            raise ValueError("Camera dimensions and frame rate must be positive")
        camera = Picamera2(int(os.getenv("PINPOINT_CAMERA_INDEX", "0")))
        try:
            controls: dict[str, Any] = {"FrameRate": fps, "AeEnable": True}
            exposure = int(os.getenv("PINPOINT_EXPOSURE_US", "0"))
            if exposure > 0:
                controls.update(AeEnable=False, ExposureTime=exposure,
                                AnalogueGain=float(os.getenv("PINPOINT_CAMERA_GAIN", "1")))
            config = camera.create_video_configuration(
                main={"size": (width, height), "format": "RGB888"},
                sensor={"output_size": (width, height), "bit_depth": 10},
                controls=controls, buffer_count=4,
            )
            camera.configure(config)
            camera.start()
            self.model = str(camera.camera_properties.get("Model", "CSI camera"))
            self.camera = camera
        except Exception:
            camera.close()
            raise

    def isOpened(self) -> bool:
        return self.camera is not None

    def read(self) -> tuple[bool, Any]:
        if self.camera is None:
            return False, None
        job = self.camera.capture_request(wait=False)
        try:
            request = self.camera.wait(job, timeout=2)
        except TimeoutError:
            self.camera.cancel_all_and_flush()
            raise RuntimeError("CSI camera stopped delivering frames") from None
        try:
            frame = request.make_array("main")
            self.metadata = request.get_metadata()
            duration = self.metadata.get("FrameDuration", 0)
            record_camera_diagnostics({
                "model": self.model, "width": frame.shape[1], "height": frame.shape[0],
                "fps": round(1_000_000 / duration, 1) if duration else 0,
                "exposureUs": self.metadata.get("ExposureTime", 0),
                "gain": round(self.metadata.get("AnalogueGain", 1), 2),
                "autoExposure": int(os.getenv("PINPOINT_EXPOSURE_US", "0")) <= 0,
                "autofocus": "AfMode" in self.camera.camera_controls,
            })
            return True, frame
        finally:
            request.release()

    def release(self) -> None:
        if self.camera is not None:
            camera, self.camera = self.camera, None
            try:
                camera.stop()
            finally:
                camera.close()
        clear_camera_diagnostics()
