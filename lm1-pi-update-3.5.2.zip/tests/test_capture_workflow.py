"""Evidence-driven workflow regressions; synthetic frames are test fixtures only."""
import asyncio
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ball_detector import RollingFrameBuffer, analyze_departure, ball_template_similarity, scale_bounds
from pinpoint_protocol import PinpointProtocol


def burst(moving=False, irregular=False):
    buffer = RollingFrameBuffer(20)
    for i in range(20):
        frame = np.full((120, 160), 40, dtype=np.uint8)
        if i < 8 or moving:
            cv2.circle(frame, (40 + (i - 7) * 5 if i >= 8 else 40, 70), 7, 230, -1)
        buffer.append(frame, i * 0.005 + (0.1 if irregular and i >= 10 else 0))
    return buffer


class AnalysisTests(unittest.TestCase):
    def test_lift_without_outgoing_track_is_not_a_measured_shot(self):
        result = analyze_departure(burst(), (31, 61, 19, 19), 8)
        self.assertEqual(result['classification'], 'unconfirmed-departure')
        self.assertEqual(result['coarseDepartureFrameIndex'], 8)
        self.assertEqual(result['lastStationaryFrameIndex'], 7)
        self.assertIsNone(result['firstMovingFrameIndex'])
        self.assertEqual(result['impactFrameIndex'], 8)
        self.assertNotIn('ballSpeedMps', result)
        self.assertTrue(result['image']['base64'])
        self.assertEqual(result['measuredFps'], 200)

    def test_motion_is_evidence_not_claim_of_club_contact(self):
        result = analyze_departure(burst(moving=True), (31, 61, 19, 19), 8)
        self.assertEqual(result['classification'], 'motion-observed')
        self.assertEqual(result['lastStationaryFrameIndex'], 7)
        self.assertEqual(result['firstMovingFrameIndex'], 8)
        self.assertEqual(result['impactFrameIndex'], 8)
        self.assertTrue(any('does not prove' in warning for warning in result['warnings']))

    def test_late_coarse_trigger_is_refined_to_full_rate_motion_window(self):
        buffer = RollingFrameBuffer(24)
        reference = None
        for i in range(24):
            frame = np.full((180, 320), 35, dtype=np.uint8)
            if i <= 7:
                center = (70, 120)
            else:
                center = (70 + (i - 7) * 38, 120 - (i - 7) * 7)
            if center[0] < frame.shape[1] - 10:
                cv2.circle(frame, center, 10, 225, -1)
                cv2.circle(frame, (center[0] - 3, center[1] - 2), 2, 90, -1)
            buffer.append(frame, i * 0.005)
            if i == 4:
                reference = frame.copy()

        result = analyze_departure(buffer, (59, 109, 23, 23), 17, ball_reference=reference)

        self.assertEqual(result['coarseDepartureFrameIndex'], 17)
        self.assertEqual(result['lastStationaryFrameIndex'], 7)
        self.assertEqual(result['firstMovingFrameIndex'], 8)
        self.assertEqual(result['impactFrameIndex'], 8)
        self.assertEqual(result['imageFrameIndex'], 7)
        self.assertEqual(result['classification'], 'motion-observed')

    def test_dropped_frames_report_timing_warning(self):
        result = analyze_departure(burst(irregular=True), (31, 61, 19, 19), 8)
        self.assertTrue(any('dropped' in warning for warning in result['warnings']))

    def test_false_removal_uses_sensor_coordinates(self):
        frame = np.full((800, 1280), 40, dtype=np.uint8)
        cv2.circle(frame, (800, 600), 30, 230, -1)
        bounds = scale_bounds((383, 283, 34, 34), (640, 400), (1280, 800))
        self.assertGreater(ball_template_similarity(frame, frame, bounds), 0.95)
        self.assertLess(ball_template_similarity(frame, np.full_like(frame, 40), bounds), 0.72)

    def test_short_contact_sheet_is_rectangular(self):
        for count in (1, 3, 5, 9):
            buffer = RollingFrameBuffer(count)
            for i in range(count):
                buffer.append(np.full((20, 32), i, dtype=np.uint8), i * 0.005)
            with TemporaryDirectory() as directory:
                buffer.save(Path(directory), 200)
                self.assertEqual(cv2.imread(str(Path(directory) / 'contact-sheet.jpg')).shape[:2], (300, 640))


class CameraWorkflowTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.env = patch.dict(os.environ, {'PINPOINT_CAPTURE_BACKEND': 'camera', 'PINPOINT_AUTO_BALL_DETECTION': 'true'})
        self.env.start()
        self.messages = []
        async def send(message):
            self.messages.append(message)
        self.protocol = PinpointProtocol(send)

    async def asyncTearDown(self):
        await self.protocol.close()
        self.env.stop()

    async def test_ball_arm_departure_analysis_image_and_rearm(self):
        for _ in range(2):
            await self.protocol.ball_presence_changed(True)
            self.assertEqual(self.protocol.state, 'armed')
            await self.protocol.ball_presence_changed(False, analysis=analyze_departure(burst(True), (31, 61, 19, 19), 8))
            self.assertEqual(self.protocol.state, 'processing')
            await self.protocol._capture_task
            self.assertEqual(self.protocol.state, 'ready')
        captures = [m for m in self.messages if m['type'] == 'capture']
        self.assertEqual(len(captures), 2)
        self.assertTrue(captures[0]['data']['image']['base64'])
        self.assertFalse(any(m['type'] in ('shot', 'putt') for m in self.messages))

    async def test_missing_evidence_never_generates_synthetic_metrics(self):
        await self.protocol.ball_presence_changed(True)
        await self.protocol.ball_presence_changed(False)
        self.assertEqual(self.protocol.state, 'ready')
        self.assertTrue(any(m['type'] == 'error' for m in self.messages))
        self.assertFalse(self.protocol.shots)

    async def test_complete_measurements_reach_existing_shot_contract(self):
        from launch_measurements import unavailable
        analysis = analyze_departure(burst(), (31, 61, 19, 19), 8)
        metrics = unavailable('test fixture')
        for key, value in {'ballSpeedMps': 40, 'clubSpeedMps': 30, 'smashFactor': 40/30,
                           'launchAngleDeg': 12, 'startDirectionDeg': 2, 'strikeXmm': 4, 'strikeYmm': 3}.items():
            metrics[key].update(value=value, status='estimated')
        analysis['measurements'] = {'metrics': metrics, 'clubId': 'driver'}
        await self.protocol.ball_presence_changed(True)
        await self.protocol.ball_presence_changed(False, analysis=analysis)
        await self.protocol._capture_task
        shot = next(message['data'] for message in self.messages if message['type'] == 'shot')
        self.assertEqual(shot['ballSpeedMps'], 40)
        self.assertEqual(shot['coarseDepartureFrameIndex'], 8)
        self.assertEqual(shot['lastStationaryFrameIndex'], 7)
        self.assertEqual(shot['measurementSource'], 'monocular-estimate')
        self.assertFalse(shot['simulated'])
        self.assertNotIn('spinRpm', shot)

    async def test_mismatched_club_calibration_blocks_complete_shot(self):
        from launch_measurements import unavailable
        analysis = analyze_departure(burst(), (31, 61, 19, 19), 8)
        metrics = unavailable('fixture')
        for metric in metrics.values(): metric.update(value=1, status='estimated')
        analysis['measurements'] = {'metrics': metrics, 'clubId': '7-iron'}
        await self.protocol.ball_presence_changed(True)
        await self.protocol.ball_presence_changed(False, analysis=analysis)
        await self.protocol._capture_task
        self.assertFalse(any(m['type'] == 'shot' for m in self.messages))
        self.assertIsNone(self.protocol.captures[0]['measurements']['metrics']['clubSpeedMps']['value'])

    async def test_new_ball_during_transfer_is_armed_afterwards(self):
        await self.protocol.ball_presence_changed(True)
        await self.protocol.ball_presence_changed(False, analysis=analyze_departure(burst(), (31, 61, 19, 19), 8))
        task = self.protocol._capture_task
        await self.protocol.ball_presence_changed(True)
        await task
        self.assertEqual(self.protocol.state, 'armed')

    async def test_send_failure_recovers_and_retains_capture(self):
        await self.protocol.ball_presence_changed(True)
        async def fail(message):
            if message['type'] == 'capture':
                raise OSError('disconnected')
        self.protocol.send_message = fail
        await self.protocol.ball_presence_changed(False, analysis=analyze_departure(burst(), (31, 61, 19, 19), 8))
        with self.assertLogs('pinpoint.protocol', level='ERROR'):
            await self.protocol._capture_task
        self.assertEqual(self.protocol.state, 'ready')
        self.assertEqual(len(self.protocol.captures), 1)


if __name__ == '__main__':
    unittest.main()
