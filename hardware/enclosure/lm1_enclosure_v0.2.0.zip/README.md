# LM1 enclosure CAD

Enclosure version **0.2.0**

This folder contains a first printable enclosure for the LM1 Raspberry Pi 5
launch monitor. It is an engineering prototype intended to verify placement,
camera framing, cooling and service access before cosmetic refinement.

## Geometry represented by the model

- Lens centre is 150 mm above the hitting surface.
- The OV9281 plate is pitched 13 degrees downward.
- The enclosure is placed approximately 500 mm downrange and 300 mm on the
  toe side of the ball, then aimed inward at the hitting area.
- The camera hood clears an approximately 100-degree horizontal field of view.
- Two generic 28 mm LED openings flank the camera.
- A replaceable 3 mm polycarbonate window is clamped behind the camera opening.
- Raspberry Pi 5 mounting bosses use the standard 58 x 49 mm hole pattern.
- A generic 2.79-inch, 16:9 OLED opening is provided in the removable top.
- A rear 40 mm fan pattern and side ventilation slots provide active airflow.

## Generated files

The `stl/v0.2.0` directory contains:

- `lm1_chassis_v0.2.0.stl` - main shell with Pi 5 bosses
- `lm1_top_oled_v0.2.0.stl` - removable roof and OLED cutout
- `lm1_sun_hood_v0.2.0.stl` - camera glare and sun hood
- `lm1_camera_mount_13deg_v0.2.0.stl` - adjustable OV9281 board plate
- `lm1_window_retainer_v0.2.0.stl` - clamp for the polycarbonate window
- `lm1_oled_retainer_v0.2.0.stl` - underside display clamp
- `lm1_led_adapter_v0.2.0.stl` - generic LED adapter; print two
- `lm1_assembly_reference_v0.2.0.stl` - assembled reference, not for printing

## Important fit assumptions

The OLED dimensions are provisional because "2.79 inch" describes only its
diagonal, not the PCB or mounting holes. Version 0.2.0 assumes:

| Item | Assumed size |
| --- | --- |
| OLED visible opening | 65 x 37 mm |
| OLED PCB pocket | 80 x 48 mm |
| OLED mounting pattern | 72 x 42 mm, M2.5 |
| OV9281 board | up to 54 x 54 mm |
| OV9281 mounting slots | 24-34 mm centres, M2.5 |
| LED body opening | 28 mm |
| Fan | 40 mm, 32 mm mounting pattern |

Measure the exact OLED and camera board before committing to a long print.
The values are grouped at the top of `lm1_case_v0_2_0.py` for easy editing.

## Hardware

- 4 x M2.5 screws for Raspberry Pi 5
- 4 x M2.5 screws and nuts for the OLED retainer
- 4 x M3 screws for the camera mount
- 4 x M3 screws for the window retainer
- 4 x M3 screws for the sun hood
- 4 x M3 screws for an optional 40 mm fan
- 90 x 68 x 3 mm clear polycarbonate camera window
- Heat-set inserts are recommended for repeatedly removed parts
- Rubber feet and a steel ballast plate are recommended for stability

Do not use acrylic for the protective window. A golf-ball impact can shatter
acrylic; polycarbonate is the safer sacrificial material. This prototype has
not been impact certified, so it must remain outside the intended ball line.

## Printing

- Material: ASA is preferred outdoors; PETG is the easier prototype material.
- Walls: 4 perimeters.
- Layer height: 0.20 mm.
- Infill: 25-35 percent, with 45 percent around the camera bracket.
- Print the chassis upright and the top panel flat.
- Print the hood on either side wall to avoid a long unsupported bridge.
- Print the retainers flat.
- Use supports only for the camera mount if the slicer cannot bridge its arms.

## Regenerate the STL files

```powershell
python -m pip install -r hardware/enclosure/requirements-cad.txt
python hardware/enclosure/lm1_case_v0_2_0.py
```

After changing camera or display geometry, increment `CASE_VERSION` and the
output folder before exporting another revision.
